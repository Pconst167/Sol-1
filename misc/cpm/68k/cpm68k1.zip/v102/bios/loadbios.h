#define LOADER  1
#define CTLTYPE 0
#define MEMDSK 0
