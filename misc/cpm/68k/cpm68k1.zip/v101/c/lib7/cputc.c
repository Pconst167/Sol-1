# include	"iodec.h"

/**
 **	put a single character
 **/

int	f_log	0;

cputc(c, fn)
char	c;
int	fn;
{
	putchar(c);
}
