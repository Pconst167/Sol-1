char *compiled "@(#) code generator -  Fri Mar 18 12:02 1983";
