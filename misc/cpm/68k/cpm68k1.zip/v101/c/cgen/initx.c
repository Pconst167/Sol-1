fflush(fp)
char	*fp;
{
	return(myfflush(fp));
}
char *null = "";
