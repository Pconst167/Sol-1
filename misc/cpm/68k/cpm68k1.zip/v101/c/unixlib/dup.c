dup(x)
	int	x;
{
	return(x);
}
