char *compiled "@(#) parser - Thu Feb 10 13:02 1983";
