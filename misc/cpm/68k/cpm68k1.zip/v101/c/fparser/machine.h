/*
 *	Use this file to determine what kind of machine you want the
 *	Alcyon stuff to run on ....
 */
#define	MC68000	1	/* 68000 version */
/*#define	VAX 	1*/		/* VAX Version */
/*#define	PDP11	1*/	/* PDP-11 Version*/
#define	CPM	1	/* CP/M Operating System*/
/*#define	UNIX	1*/	/* UNIX Operating System*/
/*#define	VMS	1*/	/* VMS Operating System*/
