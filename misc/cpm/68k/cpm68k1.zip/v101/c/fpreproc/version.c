char *compiled "@(#) preprocessor -  Mon Feb  7 16:10 1983";
