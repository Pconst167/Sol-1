/*
 *	Bill Allen's kludge version of fflush ...
 */
myfflush()
{
	return(0);
}
