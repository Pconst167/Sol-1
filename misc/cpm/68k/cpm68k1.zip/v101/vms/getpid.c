/*
 *	Getpid.c -- Whitesmith's version of UNIX getpid function
 */
getpid()
{
	return(1);
}
