main()
{
	long i;
	for(i = -1L; i < 0; i--)
		printf("i = %8lx\n",i);
}
