cc -c *.c
cc -o ar68 ar68.o ../lib/libx.a
cc -o dump dump.o ../lib/libx.a
cc -o lo68 lo68.o ../lib/libx.a
cc -o nm68 nm68.o ../lib/libx.a
cc -o nuxi nuxi.o ../lib/libx.a
cc -o prtobj prtobj.o ../lib/libx.a
cc -o reloc  reloc.o  ../lib/libx.a
cc -o sendc68 sendc68.o ../lib/libx.a
cc -o size68  size68.o  ../lib/libx.a
