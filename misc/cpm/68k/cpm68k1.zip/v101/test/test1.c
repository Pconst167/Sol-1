#include <junk.h>
#include "junk1.h"

main()
{
	printf("hello, world\n");
}
