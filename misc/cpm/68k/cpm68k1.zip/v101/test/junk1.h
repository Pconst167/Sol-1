int	junk1;
