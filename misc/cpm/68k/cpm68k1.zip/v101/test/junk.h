int	junk;
