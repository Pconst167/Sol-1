#define LOADER  0
#define CTLTYPE 0
#define MEMDSK	4
