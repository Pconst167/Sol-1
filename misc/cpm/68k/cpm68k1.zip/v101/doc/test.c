main()
{
	long	a;
	int	b;
	char	x;
	register y;
	b = blivot(x,a);
}
