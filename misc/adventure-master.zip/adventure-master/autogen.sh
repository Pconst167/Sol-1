#!/bin/sh

autoreconf -W portability -visfm
